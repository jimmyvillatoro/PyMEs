<?php 
include '../dat/cdb/db.php'; 

$idusu = $_REQUEST['idusu'];
$idobj = $_REQUEST['idobj'];
$Idobj2 = $_REQUEST['Idobj2']; 
$Ident= $_REQUEST['Ident'];

$Codigo= $_REQUEST['Codigo'];
$Nombre= $_REQUEST['Nombre'];
$Categoria= $_REQUEST['Categoria'];
$Descripcion= $_REQUEST['Descripcion'];
$Cantidad= $_REQUEST['Cantidad'];
$Precio= $_REQUEST['Precio'];
$Descuento= $_REQUEST['Descuento'];
$Maximo= $_REQUEST['Maximo'];
$Minimo= $_REQUEST['Minimo'];
$Caducidad= $_REQUEST['Caducidad'];
$Ubicacion= $_REQUEST['Ubicacion'];
$Foto= $_REQUEST['Foto'];
$Enlace= $_REQUEST['Enlace'];
$Estado= $_REQUEST['Estado'];

 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; 
$resultado=mysqli_query($db_connection, "SELECT * FROM objetos WHERE Codigo LIKE '".$Codigo."'" ); 
if (mysqli_num_rows($resultado)>0) {
 header("Location: ../usuarios.php?idusu=$idusu&idses=$idses&idobj=$idobj&Idobj2=$Idobj2"); 
} else {  
$insert_value ="INSERT INTO objetos(Codigo, Nombre, Categoria, Descripcion, Cantidad, Precio, Descuento, Maximo, Minimo, Caducidad, Ubicacion, Foto, Enlace, Estado, Idobj2, Ident) VALUES ( '".$Codigo."',  '".$Nombre."',  '".$Categoria."',  '".$Descripcion."',  '".$Cantidad."',  '".$Precio."', '".$Descuento."', '".$Maximo."',  '".$Minimo."',  '".$Caducidad."',  '".$Ubicacion."',  '".$Foto."',  '".$Enlace."',  '".$Estado."',  '".$Idobj2."',  '".$Ident."')";

$retry_value = mysqli_query($db_connection,$insert_value);}
$resultado=mysqli_query($db_connection, "SELECT idobj  FROM  objetos  WHERE Codigo = '".$Codigo."'" ); 
 while ($row =mysqli_fetch_array($resultado))   $idobj =$row['idobj']; 
 header("Location: ../usuarios.php?idusu=$idusu&idses=$idses&idobj=$idobj&Idobj2=$Idobj2"); 
mysqli_free_result($retry_value);
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>