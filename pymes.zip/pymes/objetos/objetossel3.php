<?php
session_start(); 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description: automata finitos" content="">
        <meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">
		<link href="../dat/css/style.css" rel="stylesheet" type="text/css" media="all" />
		<title>objetos</title> 
  		<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
        <script type="text/javascript" src="tablecloth/tablecloth.js"></script>
        <title>entidades</title> 
<style>
form{
	margin:1em 0;
	padding:.2em 20px;
	background:#eee;
}
</style> 
  
<?php
include '../dat/cdb/db.php';
$idusu = utf8_decode($_GET['idusu']); 
$Ident = utf8_decode($_GET['Ident']); 
$Idobj = utf8_decode($_GET['Idobj']); 
$selCombo1= utf8_decode($_GET['selCombo1']);
$selCombo2= utf8_decode($_GET['selCombo2']);

if($_SESSION['Ident']!=$idusu)
{
 echo '<a href="sesion.php" title="" class="round">Inicie sesion</a>';
  header('Location: sesion.php?idses='.$_SESSION['Ident'].'');
  exit;
}

$resultado=mysqli_query($db_connection, "SELECT Nombres, Apellidos FROM entidades WHERE Ident = '".$idusu."' ");
while ($row =mysqli_fetch_array($resultado)) {
   	$nombres=$row['Nombres'];
   	$nombres.=" ".$row['Apellidos'];
   }
mysqli_free_result($resultado);


mysqli_close($db_connection);
?>

</head>
<!-- Body -->
	<body>
		<div id="wrapper">
			<div id="logo">
				<h1>Control de<span> PyME</span></h1>
				<p>Area para tu PyME</p>
			</div>
			<div id="page" class="round">
				<div id="menu" class="round">
<ul>
<li><a href="objetosser.php?idusu=<?php echo $idusu; ?>" title="" class="round">Regresar</a></li>
<li><a href="../usuarios.php?idusu=<?php echo $idusu; ?>&Ident=<?php echo $Ident; ?>" title="" class="round">Administración</a></li>
</ul>
			</div>
<div id="content" class="round">
<p>Usuario:<a style="color:orange;"> <?php echo $nombres; ?> </a></p>
<div id="wrapper2" class="round">					
<div id="sidebar2" class="round">  



        <div> <h2>objetos</h2> </div> 
 
<div id='container'>
	<h1>Selección de Registros para Editar</h1>
 <div id='content'><table>
  <tr><th>Editar</th>
<th>Codigo</th> 
<th>Nombre</th> 
<th>Categoria</th> 
<th>Descripcion</th> 
<th>Cantidad</th> 
<th>Precio</th> 
<th>Descuento</th> 
<th>Maximo</th> 
<th>Minimo</th> 
<th>Caducidad</th> 
<th>Ubicacion</th> 
<th>Foto</th> 
<th>Enlace</th> 
<th>Estado</th> 

<?php
include '../dat/cdb/db.php'; 
$Idobj= utf8_decode($_GET['Idobj']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM objetos WHERE Idobj = '".$Idobj."' " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$Idobj=$row['Idobj'];
$Codigo=$row['Codigo'];
$Nombre=$row['Nombre'];
$Categoria=$row['Categoria'];
$Descripcion=$row['Descripcion'];
$Cantidad=$row['Cantidad'];
$Precio=$row['Precio'];
$Descuento=$row['Descuento'];
$Maximo=$row['Maximo'];
$Minimo=$row['Minimo'];
$Caducidad=$row['Caducidad'];
$Ubicacion=$row['Ubicacion'];
$Foto=$row['Foto'];
$Enlace=$row['Enlace'];
$Estado=$row['Estado'];
$Idobj2=$row['Idobj2'];
$Ident=$row['Ident'];
 ?>
</tr><tr><tr><form action="objetosupd3.php" method="POST"> 
<input type='hidden' name='Idobj' value='<?php echo utf8_decode($_GET['Idobj']); ?>'> 
<input type='hidden' name='idusu' value='<?php echo utf8_decode($_GET['idusu']); ?>'> 
 
<td><div><button type='submit' class='btn btn-success'>Editar</button> </div></td> 

 
<td><div><input type='number' name='Codigo'  class='form-control' placeholder='Codigo' value='<?php echo $Codigo; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='text' name='Nombre'  class='form-control' placeholder='Nombre' value='<?php echo $Nombre; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='text' name='Categoria'  class='form-control' placeholder='Categoria' value='<?php echo $Categoria; ?>' class='form-input' required> </div></td>  
 
<td><div><textarea id='Descripcion' name='Descripcion' rows='5' cols='60'> <?php echo $Descripcion; ?> </textarea> </div></td>  
 
<td><div><input type='TEXT' name='Cantidad'   class='form-control' placeholder='Cantidad' value='<?php echo $Cantidad; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='TEXT' name='Precio'   class='form-control' placeholder='Precio' value='<?php echo $Precio; ?>' class='form-input' required> </div></td>  
<td><div><input type='TEXT' name='Descuento'  class='form-control' placeholder='Descuento' value='<?php echo $Descuento; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='number' name='Maximo'  class='form-control' placeholder='Maximo' value='<?php echo $Maximo; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='number' name='Minimo'  class='form-control' placeholder='Minimo' value='<?php echo $Minimo; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='datetime' name='Caducidad'  class='form-control' placeholder='Caducidad' value='<?php echo $Caducidad; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='text' name='Ubicacion'  class='form-control' placeholder='Ubicacion' value='<?php echo $Ubicacion; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='text' name='Foto'  class='form-control' placeholder='Foto' value='<?php echo $Foto; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='text' name='Enlace'  class='form-control' placeholder='Enlace' value='<?php echo $Enlace; ?>' class='form-input' required> </div></td>  
 
<td><div><input type='number' name='Estado'  class='form-control' placeholder='Estado' value='<?php echo $Estado; ?>' class='form-input' required> </div></td>  

</form> 
 <?php } mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</tr></table>	</div>
</div></br></br><a href="objetosser.php?idusu=<?php echo $idusu; ?>">Regresar</a>
<h3>Información</h3>
<ul>
<li>Los datos están seguros en nuestra nube, pero puedes tener instalada nuestra plataforma en tu sitio web. Contactanos</li>
<li align="center">
<img src="../dat/ima/datos.jpg" alt="" width="200" height="150" class="round" />     
</li>
<li>Nosotros hicimos está plataforma pensando en un mejor rendimiento para su PyME.</li>
</ul>
<!-- End Sidebar -->
</div></div>
<!-- End Content -->
</div>
<div style="clear: both"></div>
<!-- End Wrapper 2 -->
</div>
<!-- End Page -->
</div>
<!-- End Wrapper -->
</div>
<div id="footer">
<p>copyright &copy; 2021 Jimmy Villatoro<a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p></div>
<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div>
</body>
</html>
  
