<!DOCTYPE html>
<html lang="en">
<head>
<!-- basic -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- mobile metas -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="initial-scale=1, maximum-scale=1"> 
 
<title></title>
<meta name="keywords" content="">
<meta name="description: formulario Landing" content="">
<meta name="author: Jimmy Villatoro" content="">

<style>
/*
project: css landingpage
author: Jimmy Villatoro
*/

body { font: .8em "Trebuchet MS", Verdana, Helvetica, sans-serif; color: #666;  background: #F7FCFF url(../images/bg.gif) repeat-x; }
a { color: #AF1515; cursor: pointer; }
a:hover { color: #7D1919; }
h1 { font-size: 3em; clear: both; margin: 0 0 5px; }
h2 { font: normal 1.6em Arial; color: #3D3C3B; margin: 0 0 15px; }
p  { margin: 0 0 15px; line-height: 1.7em; }

.background { background: url(../images/bg.jpg) no-repeat left 42px; }
/*---------------------------------------------------------------------
    popup begin css
---------------------------------------------------------------------*/

.vfpop {
	background: none repeat scroll 0 0 #FFA200;
	border: 1px solid #DDDDDD;
	border-radius: 6px 6px 6px 6px;
	top: 122px;
	left: auto;
	margin-left: 74px;
	padding: 10px 0 0;
	position: fixed;
	text-align: center;
	width: 290px;
	z-index: 15;
}

.btn {
background-color: #FF0000; /* Green */
border: 1px solid white;
color: white;
padding: 15px 32px;
border-radius: 6px 6px 6px 6px; 
text-align: center;
text-decoration: none;
display: inline-block;
font-size: 16px;
}

.btn:hover {
	background-color: rgb(65, 199, 70); /* Green Claro */
	box-shadow: 0 12px 16px 0 rgba(0, 0, 0, 0.24), 0 17px 50px 0 rgba(0,0,0,0.19);
	opacity: 0.5;
	color: white;
}



/*---------------------------------------------------------------------
    end popup css
---------------------------------------------------------------------*/




</style>
 
</head>
<!-- body -->
<body> 
 
<p class="centrado">
<img src="images/recepcion1024x700.jpg"  alt="bienvenido"  width="1024" height="700" title="Exposición de Landing page">
 </p>
 

<div class="vfpop">
<h3>Registrarte</h3>
<form action="landing2.php" method="POST"><input type='hidden' name=Ident value='<?php echo utf8_decode($_GET['Ident']); ?>'> 
 

<div><input type='text' name='Empresa'  class='form-control' placeholder='Empresa' class='form-input' required>
                </div>  
<div><input type='text' name='Nombres'  class='form-control' placeholder='Nombres' class='form-input' required>
                </div>  
<div><input type='text' name='Apellidos'  class='form-control' placeholder='Apellidos' class='form-input' required>
                </div>  
<div><input type='text' name='Direccion'  class='form-control' placeholder='Direccion' class='form-input' required>
                </div>  
<div><input type='text' name='Rfc'  class='form-control' placeholder='Rfc' class='form-input' required>
                </div>  
<div><input type='text' name='Movil'  class='form-control' placeholder='Movil' class='form-input' required>
                </div>  
<div><input type='email' name='Correo'  class='form-control' placeholder='Correo' class='form-input' required>
                </div>  
<div><input type='text' name='Pass'  class='form-control' placeholder='Contrasena' class='form-input' required>
                </div>  
 
<div>
             <button type='submit' class='btn btn-success'>Registrarme</button>
             </div>
             </form>
              </div>
</body>
</html>