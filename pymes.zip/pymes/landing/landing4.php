
<!DOCTYPE html>
<html lang="en">
<head>
<!-- basic -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- mobile metas -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="initial-scale=1, maximum-scale=1"> 
 
<title></title>
<meta name="keywords" content="">
<meta name="description: formulario Landing" content="">
<meta name="author: Jimmy Villatoro" content="">
<link rel="stylesheet" type="text/css" media="screen" href="style.css" /> 
 
<?php 
include 'dat/cdb/db.php';
$idusu= $_GET['idusu'];
$Ident= $_GET['Ident'];
?>
</head>
<!-- body -->
<body> 
 
<p class="centrado"><a href="../sesion.php?idusu=<?php echo $idusu; ?>&Ident=<?php echo $Ident; ?>"> 
<img src="images/gracias1024x576.jpg"  alt="bienvenido"  width="1024" height="700" title="Exposición de Landing page">
 </p>
 
</body>
</html>