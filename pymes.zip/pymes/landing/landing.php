<?php 

include '../dat/cdb/db.php'; 
	

// sql Crea la tabla usando Lenguaje PHP
$sql = "CREATE TABLE IF NOT EXISTS `entidades` (
  `Ident` int(11) NOT NULL AUTO_INCREMENT,
  `Empresa` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Nombres` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Apellidos` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Direccion` varchar(250) COLLATE latin1_spanish_ci NOT NULL,
  `Rfc` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `Movil` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `Correo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Pass` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `Foto` varchar(250) COLLATE latin1_spanish_ci NOT NULL,
  `Fecha` datetime NOT NULL,
  `Estado` tinyint(4) NOT NULL,
  `Tipo` int(11) NOT NULL,
  `Ident2` int(11) NOT NULL,
  PRIMARY KEY (`Ident`),
  KEY `Ident2` (`Ident2`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci
)";

// Se verifica si la tabla ha sido creado
if ($db_connection->query($sql) === TRUE) {
    echo "la tabla ha sido creado exitosamente.";
} else {
    echo "Hubo un error al crear la tabla, ya que ella esta creada." . $conn->error;
}
 
// Cerramos la conexi車n
$db_connection->close();	

 ?>