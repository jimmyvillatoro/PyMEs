<?php 
include '../dat/cdb/db.php'; 

$idusu = $_REQUEST['idusu'];
$Ident = $_REQUEST['Ident'];
$Idmov = $_REQUEST['Idmov']; 
$Idobj = $_REQUEST['Idobj'];

$Cantidad= $_REQUEST['can'];
$Precio= $_REQUEST['pre'];
$Descuento= $_REQUEST['des'];
$Importe=($Cantidad*$Precio)-$Descuento;

 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; 
$resultado=mysqli_query($db_connection, "SELECT * FROM detalle WHERE Idobj ='".$Idobj."' && Idmov='".$Idmov."'" ); 
if (mysqli_num_rows($resultado)>0) {
  
  //actualizar detalle

$resultado=mysqli_query($db_connection, "SELECT Cantidad FROM  detalle  WHERE Idobj ='".$Idobj."' && Idmov='".$Idmov."' "); 

 while ($row =mysqli_fetch_array($resultado))   
 $can =$row['Cantidad']; 
 
 $Cantidad1=$can+$Cantidad;
 $Importe=($Cantidad*$Precio)-$Descuento;
 
$update_value = "UPDATE detalle SET Cantidad= '".$Cantidad1."', Precio= '".$Precio."', Descuento= '".$Descuento."', Importe= '".$Importe."', Fecha= '".$dt."', Idobj= '".$Idobj."', Idmov= '".$Idmov."'   WHERE   Idobj ='".$Idobj."' && Idmov='".$Idmov."' " ;  
$retry_value = mysqli_query($db_connection,$update_value);


 //update obj
 
 $result=mysqli_query($db_connection, "SELECT Cantidad FROM  objetos WHERE Idobj ='".$Idobj."' "); 
 while ($row =mysqli_fetch_array($result))   
 $cantidadx =$row['Cantidad']; 
 
 $Cantidady=$cantidadx+$Cantidad;
 
 $update_value = "UPDATE objetos SET Cantidad= '".$Cantidady."'  WHERE   Idobj = '".$Idobj."'" ;  
$retry_value = mysqli_query($db_connection,$update_value);

 header('Location: almacen.php?idusu='.$idusu.'&Idmov='.$Idmov.'&Ident='.$Ident.'&Idobj='.$Idobj.'&men='.$men.'');
} else {  
$insert_value ="INSERT INTO detalle(Cantidad, Precio, Descuento, Importe, Fecha, Idobj, Idmov) VALUES ( '".$Cantidad."',  '".$Precio."',  '".$Descuento."',  '".$Importe."',  '".$dt."',  '".$Idobj."',  '".$Idmov."')";

$retry_value = mysqli_query($db_connection,$insert_value);
$resultado=mysqli_query($db_connection, "SELECT Cantidad  FROM  detalle  WHERE Idobj ='".$Idobj."' && Idmov='".$Idmov."' "); 
 while ($row =mysqli_fetch_array($resultado))   
  $can =$row['Cantidad']; 
 
 //update obj
 
 $result=mysqli_query($db_connection, "SELECT Cantidad FROM  objetos WHERE Idobj ='".$Idobj."' "); 
 while ($row =mysqli_fetch_array($result))   
 $cantidadx =$row['Cantidad']; 
 
 $Cantidady=$cantidadx+$can;
 
 $update_value = "UPDATE objetos SET Cantidad= '".$Cantidady."'  WHERE   Idobj = '".$Idobj."'" ;  
$retry_value = mysqli_query($db_connection,$update_value);
 
 header('Location: almacen.php?idusu='.$idusu.'&Idmov='.$Idmov.'&Ident='.$Ident.'&Idobj='.$Idobj.'&men='.$men.'');
mysqli_free_result($retry_value);}
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>