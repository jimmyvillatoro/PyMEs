<?php 
include '../dat/cdb/db.php'; 

$idusu = $_GET['idusu'];
$Iddet = $_GET['Iddet'];
$Idobj = $_GET['Idobj'];
$Ident = $_GET['Ident']; 
$Idmov = $_GET['Idmov']; 

$resultado=mysqli_query($db_connection, "SELECT Cantidad FROM detalle WHERE Iddet = '".$Iddet."'" );  
if (mysqli_num_rows($resultado)>0) {
 while ($row =mysqli_fetch_array($resultado))   
 $can1 =$row['Cantidad']; 

$result2=mysqli_query($db_connection, "SELECT Cantidad FROM  objetos WHERE Idobj ='".$Idobj."' "); 
 while ($row2 =mysqli_fetch_array($result2))   
 $can2 =$row2['Cantidad']; 
 
 $can3=$can2 - $can1;
 
$update_value = "UPDATE objetos SET Cantidad= '".$can3."'  WHERE   Idobj = '".$Idobj."'" ; 
$retry_value = mysqli_query($db_connection,$update_value);

$delete_value ="DELETE FROM detalle WHERE Iddet = '".$Iddet."'";  
$retry_value = mysqli_query($db_connection,$delete_value);
 header('Location: almacen.php?idusu='.$idusu.'&Idmov='.$Idmov.'&Ident='.$Ident.'&Idobj='.$Idobj.'&men='.$men.'');
mysqli_free_result($retry_value);
} else {  
 header('Location: almacen.php?idusu='.$idusu.'&Idmov='.$Idmov.'&Ident='.$Ident.'&Idobj='.$Idobj.'&men='.$men.''); }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>