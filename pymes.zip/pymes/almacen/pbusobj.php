<?php

include '../dat/cdb/db.php';

$cor = $_REQUEST['cor'];
$idusu = $_REQUEST['idusu'];
$Ident = $_REQUEST['Ident'];
$Idmov = $_REQUEST['Idmov'];

$resultado=mysqli_query($db_connection, "SELECT Idobj, Codigo FROM objetos WHERE Codigo = '".$cor."' ");

$c=0;

if (mysqli_num_rows($resultado)>0)
{
while ($row =mysqli_fetch_array($resultado))
{
   	 $Idobj=$row[Idobj];
$c++;
}

$men="Objeto consultado por Codigo";
header('Location: almacen.php?idusu='.$idusu.'&Idmov='.$Idmov.'&Ident='.$Ident.'&Idobj='.$Idobj.'&men='.$men.'');
}


mysqli_free_result($resultado);
mysqli_close($db_connection);
?>