<?php 
include '../dat/cdb/db.php'; 

$idusu = $_REQUEST['idusu'];
$tipo = $_REQUEST['selCombo1'];


date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; 

$insert_value ="INSERT INTO movimientos( Fecha, Tipo, Estado, Ident) VALUES ('".$dt."', '".$tipo."',  0, '".$idusu."')";

$retry_value = mysqli_query($db_connection,$insert_value);

mysqli_free_result($retry_value);

$resultado=mysqli_query($db_connection, "SELECT Idmov  FROM  movimientos  WHERE Fecha LIKE '".$dt."' "); 
 while ($row =mysqli_fetch_array($resultado))   
 $Idmov =$row['Idmov']; 
 header("Location: almacen.php?idusu=$idusu&Idmov=$Idmov"); 

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>