<?php
session_start(); 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Almacen PyME</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="../dat/css/style.css" rel="stylesheet" type="text/css" media="all" />


<?php
include '../dat/cdb/db.php';
$idusu = utf8_decode($_GET['idusu']); 
$Ident = utf8_decode($_GET['Ident']); 
$Idmov= utf8_decode($_GET['Idmov']);
$Idobj= utf8_decode($_GET['Idobj']);
$men = utf8_decode($_GET['men']);

if($_SESSION['Ident']!=$idusu)
{
 echo '<a href="sesion.php" title="" class="round">Inicie sesion</a>';
  header('Location: ../sesion.php?idses='.$_SESSION['Ident'].'');
  exit;
}


$resultado=mysqli_query($db_connection, "SELECT Nombres, Apellidos FROM entidades WHERE Ident = '".$idusu."' ");
while ($row =mysqli_fetch_array($resultado)) {
   	$nombres=$row[Nombres];
   	$nombres.=" ".$row[Apellidos];
   }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>

<SCRIPT language=JavaScript>

function tick() {
  var hours, minutes, seconds, ap;
  var intHours, intMinutes, intSeconds;
  var today;
  today = new Date();
  intHours = today.getHours();
  intMinutes = today.getMinutes();
  intSeconds = today.getSeconds();

  switch(intHours){
       case 0:
           intHours = 12;
           hours = intHours+":";
           ap = "A.M.";
           break;
       case 12:
           hours = intHours+":";
           ap = "P.M.";
           break;
       case 24:
           intHours = 12;
           hours = intHours + ":";
           ap = "A.M.";
           break;
       default:    
           if (intHours > 12)
           {
             intHours = intHours - 12;
             hours = intHours + ":";
             ap = "P.M.";
             break;
           }
           if(intHours < 12)
           {
             hours = intHours + ":";
             ap = "A.M.";
           }
    }       
       

  if (intMinutes < 10) {
     minutes = "0"+intMinutes+":";
  } else {
     minutes = intMinutes+":";
  }

  if (intSeconds < 10) {
     seconds = "0"+intSeconds+" ";
  } else {
     seconds = intSeconds+" ";
  } 

  timeString = hours+minutes+seconds+ap;
  Clock.innerHTML = timeString;
  window.setTimeout("tick();", 100);
}

window.onload = tick;
</SCRIPT>
	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				<h1>Almacen <span> PyME</span></h1>
				<p>Area de Almacen </p>
<?php
$dir = '../dat/usuarios/';$foto=$dir.$foto;echo "	<img src='".$foto."' alt='' width='100' height='100' class='round' align='right' />";
?>
			</div>
			
			<div id="page" class="round">
			<div id="menu" class="round">
			<ul>
<li><a href="almacen.php?idusu=<?php echo $idusu; ?>" title="" class="round active">Área de Almacen</a></li>
<li><a href="../index.php" title="" class="round active">Salir</a></li>
			</ul>
					

		
			</div>
		
<div id="content" class="round">	
<h2 align="right">	<a id=Clock style="FONT-SIZE: 40px; COLOR: GREEN; FONT-FAMILY: " class="current"></a></h2>

<p>Usuario:<a style="color:orange;"> <?php echo $nombres; ?> </a></p>

<p>Mensaje:<a style="color:red;"> ;]. <?php echo utf8_decode($men);
 ?> </a></p>


<div id="wrapper2" class="round">			
<div id="sidebar2" class="round">

<form action="movimientosadd.php" method="POST" >
<input type="hidden" name="idusu"   value="<?php echo utf8_decode($_GET['idusu']); ?>">
<input type="hidden" name="selCombo1" value="<?php echo utf8_decode($_GET['selCombo1']); ?>">
Tipo de almacenenado: 
<SELECT NAME="selCombo1" SIZE=1 onchange = "this.form.submit()"> 
<OPTION VALUE="3"> EFECTIVO </OPTION>
<OPTION VALUE="4"> CREDITO </OPTION>
</SELECT>  
<button type="submit"><img src="../dat/ima/agregar.jpg" alt="" width="40" height="40"  class="round"/></button>
</form>

<h3>Buscar Proveedor</h3>

<form action="pbusent.php" method="POST" >
<input type="hidden" name="idusu"   value="<?php echo utf8_decode($_GET['idusu']); ?>">
<input type="hidden" name="Ident" value="<?php echo utf8_decode($_GET['Ident']); ?>">
<input type="hidden" name="Idmov" value="<?php echo utf8_decode($_GET['Idmov']); ?>">
    
<div>
<div>
<input type="text" name="cor" class="form-control" placeholder="Correo, Empresa, Apellidos, Nombres" class="form-input" size="30" required>
<button type="submit"><img src="../dat/ima/busca.png" alt="" width="40" height="40"  class="round"/></button>
</div>
</div>
</form>

<?php
include '../dat/cdb/db.php';
$Ident= utf8_decode($_GET['Ident']);
$resultx=mysqli_query($db_connection, "SELECT Ident, Empresa, Nombres, Apellidos, Foto  FROM entidades WHERE Ident = '".$Ident."' ");

if (mysqli_num_rows($resultx)>0)
{

while ($rowx =mysqli_fetch_array($resultx)){
    $nom=$rowx[Nombres];
    $ape=$rowx[Apellidos];
    $foto=$rowx[Foto];

$dir = '../dat/alumnos/';
$foto=$dir.$foto;

 echo "	<img src='".$foto."' alt='' width='100' height='100' class='round' align='right' />";

?>

<center>	<a style="FONT-SIZE: 30px; COLOR: GREEN; FONT-FAMILY: " class="current">PROVEEDOR: <?php echo $nom; ?> <?php echo $ape; ?> </a> </center>

<?php
}
}
mysqli_free_result($resultx);
mysqli_close($db_connection);
?>

<h3>Buscar Producto o Servicio</h3> 

<form action="pbusobj.php" method="POST" >
<input type="hidden" name="idusu"   value="<?php echo utf8_decode($_GET['idusu']); ?>">
<input type="hidden" name="Ident" value="<?php echo utf8_decode($_GET['Ident']); ?>">
<input type="hidden" name="Idmov" value="<?php echo utf8_decode($_GET['Idmov']); ?>">
<div>
<div>
<input type="text" name="cor" class="form-control" placeholder="Codigo de Barras" class="form-input" size="30" required>
<button type="submit"><img src="../dat/ima/busca.png" alt="" width="40" height="40"  class="round"/></button>
</div>
</div>
</form>

<?php
include '../dat/cdb/db.php';
$Idobj= utf8_decode($_GET['Idobj']);
$resultx=mysqli_query($db_connection, "SELECT Idobj, Codigo, Nombre, Precio, Foto  FROM objetos WHERE Idobj = '".$Idobj."' ");

if (mysqli_num_rows($resultx)>0)
{

while ($rowx =mysqli_fetch_array($resultx)){
    $nom2=$rowx[Nombre];
    $pre=$rowx[Precio];
    $foto=$rowx[Foto];

$dir = '../dat/alumnos/';
$foto=$dir.$foto;

 echo "<img src='".$foto."' alt='' width='100' height='100' class='round' align='right' /> ";

?>

<center>	<a style="FONT-SIZE: 30px; COLOR: GREEN; FONT-FAMILY: " class="current">Objeto: <?php echo $nom2; ?> $ <?php echo $pre; ?> </a> </center>

<?php
}
}
mysqli_free_result($resultx);
mysqli_close($db_connection);
?>



<h3>Datos del Recibo</h3>

<form action="detalleadd.php" method="POST" >
      
<input type="hidden" name="idusu"   value="<?php echo utf8_decode($_GET['idusu']); ?>">
<input type="hidden" name="Ident"  value="<?php echo utf8_decode($_GET['Ident']); ?>">
<input type="hidden" name="Idmov"  value="<?php echo utf8_decode($_GET['Idmov']); ?>">
<input type="hidden" name="Idobj"  value="<?php echo utf8_decode($_GET['Idobj']); ?>">
<div>
<div>
<input type="text" name="can" class="form-control" placeholder="Cantidad" class="form-input" size="5" value="1">
<input type="text" name="nom" class="form-control" placeholder="Nombre" class="form-input" size="20" value="<?php echo $nom2; ?>">
<input type="text" name="pre" class="form-control" placeholder="Precio" class="form-input" size="5" value="<?php echo $pre; ?>" required>
<input type="text" name="des" class="form-control" placeholder="Descuento" class="form-input" size="5" value="0">
<button type="submit"><img src="../dat/ima/agregar.jpg" alt="" width="40" height="40"  class="round"/></button>
</div>
</div>
</form>

<?php
include '../dat/cdb/db.php';
$idusu = utf8_decode($_GET['idusu']); 
$Ident = utf8_decode($_GET['Ident']); 
$Idmov= utf8_decode($_GET['Idmov']);
$Idobj= utf8_decode($_GET['Idobj']);
$men = utf8_decode($_GET['men']);

$resultado6=mysqli_query($db_connection, "SELECT Iddet, Cantidad, Precio, Descuento, Importe, Fecha, Idobj, Idmov FROM detalle WHERE Idmov='".$Idmov."' ");

if (mysqli_num_rows($resultado6)>0)
{			  
      while ($row6 =mysqli_fetch_array($resultado6)){
   $Iddet=$row6[Iddet];
   $can=$row6[Cantidad];
   $pre=$row6[Precio];
   $des=$row6[Descuento];
   $imp=$row6[Importe];
   $fec=$row6[Fecha];
   $Idobj=$row6[Idobj];
   $Idmov=$row6[Idmov];
   

   $resultx=mysqli_query($db_connection, "SELECT Nombre  FROM objetos WHERE Idobj = '".$Idobj."' ");
if (mysqli_num_rows($resultx)>0)
while ($rowx =mysqli_fetch_array($resultx))
    $nom2=$rowx[Nombre];
   
   
?>
</br><?php echo $Iddet; ?> - <?php echo $can; ?> - <?php echo $nom2; ?> - <?php echo $pre; ?> - <?php echo $des; ?> - <?php echo $imp; ?> - <?php echo $fec; ?> - <?php echo $Idobj; ?> - <?php echo $Idmov; ?>
<button type="submit"><a href="detalledel.php?idusu=<?php echo $idusu; ?>&Ident=<?php echo $Ident; ?>&Idmov=<?php echo $Idmov; ?>&Idobj=<?php echo $Idobj; ?>&Iddet=<?php echo $Iddet; ?>"> <img src="../dat/ima/borra.png" alt="" width="40" height="40"  class="round"/> </a></button>
<?php
      }
}

$resultado=mysqli_query($db_connection, "SELECT Iddet, Cantidad, Precio, Descuento, Importe, Fecha, Idobj, Idmov FROM detalle WHERE Idmov='".$Idmov."' ");
if (mysqli_num_rows($resultado)>0)
while ($row =mysqli_fetch_array($resultado)){
   $Iddet=$row[Iddet];
   $can=$row[Cantidad];
   $pre=$row[Precio];
   $des=$row[Descuento];
   $imp=$row[Importe];
   $fec=$row[Fecha];
   $Idobj=$row[Idobj];
   $Idmov=$row[Idmov];
$Subtotal=$imp+$Subtotal;
$Descuento= $des+$Descuento;
$Iva=$Subtotal*.16;
$Total=$Subtotal+$Iva;
}


$Descuento=round($Descuento, 2);
$Subtotal=round($Subtotal, 2);
$Iva=round($Iva, 2);
$Total=round($Total, 2);

mysqli_free_result($resultado6);
mysqli_close($db_connection);
 ?>	
 
</br>
Subtotal: $<?php echo $Subtotal; ?> Iva: $<?php echo $Iva; ?> Total: $<?php echo $Total; ?> 
</br>

<form action="ticket.php" method="POST" >
<input type="hidden" name="idusu"   value="<?php echo utf8_decode($_GET['idusu']); ?>">
<input type="hidden" name="Ident"  value="<?php echo utf8_decode($_GET['Ident']); ?>">
<input type="hidden" name="Idmov"  value="<?php echo utf8_decode($_GET['Idmov']); ?>">
<button type="submit"><img src="../dat/ima/imp.png" alt="" width="40" height="40"  class="round"/></button>
</form>
</div></div>
					<!-- End Content -->
					</div>
					<div style="clear: both"></div>
				<!-- End Wrapper 2 -->
				</div>
			<!-- End Page -->
			</div>
		<!-- End Wrapper -->
		</div>
		
	<div id="footer">
<p>copyright &copy; 2020 yaprendo <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p>
</div>

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.
</div>

</body>
</html>