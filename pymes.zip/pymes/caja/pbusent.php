<?php

include '../dat/cdb/db.php';

$cor = $_REQUEST['cor'];
$idusu = $_REQUEST['idusu'];
$Ident = $_REQUEST['Ident'];
$Idmov = $_REQUEST['Idmov'];

$resultado=mysqli_query($db_connection, "SELECT Ident, Empresa FROM entidades WHERE Correo = '".$cor."' && Tipo=3");

$c=0;

if (mysqli_num_rows($resultado)>0)
{
while ($row =mysqli_fetch_array($resultado))
{
   	 $Ident=$row[Ident];
$c++;
}

$men="Consultado por Correo";
header('Location: caja.php?idusu='.$idusu.'&Idmov='.$Idmov.'&Ident='.$Ident.'&men='.$men.'');
}

$resultado=mysqli_query($db_connection, "SELECT Ident, Empresa FROM entidades WHERE Empresa = '".$cor."' && Tipo=3 ");

if (mysqli_num_rows($resultado)>0)
{
while ($row =mysqli_fetch_array($resultado))
{
   	 $Ident=$row[Ident];
$c++;
}

$men="Consultado por Apellido";
header('Location: caja.php?idusu='.$idusu.'&Idmov='.$Idmov.'&Ident='.$Ident.'&men='.$men.'');
}


$resultado=mysqli_query($db_connection, "SELECT Ident, Empresa FROM entidades WHERE Apellidos = '".$cor."' && Tipo=3");

if (mysqli_num_rows($resultado)>0)
{
while ($row =mysqli_fetch_array($resultado))
{
   	 $Ident=$row[Ident];
$c++;
}

$men="Consultado por Apellido";
header('Location: caja.php?idusu='.$idusu.'&Idmov='.$Idmov.'&Ident='.$Ident.'&men='.$men.'');
}



$resultado=mysqli_query($db_connection, "SELECT Ident, Empresa FROM entidades WHERE Nombres = '".$cor."' && Tipo=3 ");

if (mysqli_num_rows($resultado)>0)
{
while ($row =mysqli_fetch_array($resultado))
{
   	 $Ident=$row[Ident];
$c++;
}

$men="Consultado por Nombres";
header('Location: caja.php?idusu='.$idusu.'&Idmov='.$Idmov.'&Ident='.$Ident.'&men='.$men.'');
}

if (mysqli_num_rows($resultado)<=0 && $c==0)
{
$men="No se encuentra";

header('Location: caja.php?idusu='.$idusu.'&Idmov='.$Idmov.'&Ident='.$Ident.'&men='.$men.'');
}

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>