-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 16-07-2021 a las 13:48:37
-- Versión del servidor: 5.7.23-23
-- Versión de PHP: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `yaprendo_pymes`
--
CREATE DATABASE IF NOT EXISTS `yaprendo_pymes` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `yaprendo_pymes`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `chat`
--

DROP TABLE IF EXISTS `chat`;
CREATE TABLE IF NOT EXISTS `chat` (
  `chatid` int(11) NOT NULL AUTO_INCREMENT,
  `sender_userid` int(11) NOT NULL,
  `reciever_userid` int(11) NOT NULL,
  `message` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`chatid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `chat_login_details`
--

DROP TABLE IF EXISTS `chat_login_details`;
CREATE TABLE IF NOT EXISTS `chat_login_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Ident` int(11) NOT NULL,
  `last_activity` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_typing` enum('no','yes') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle`
--

DROP TABLE IF EXISTS `detalle`;
CREATE TABLE IF NOT EXISTS `detalle` (
  `Iddet` int(11) NOT NULL AUTO_INCREMENT,
  `Cantidad` float DEFAULT NULL,
  `Precio` float DEFAULT NULL,
  `Descuento` float DEFAULT NULL,
  `Importe` float DEFAULT NULL,
  `Fecha` datetime DEFAULT NULL,
  `Idobj` int(11) NOT NULL,
  `Idmov` int(11) NOT NULL,
  PRIMARY KEY (`Iddet`),
  KEY `Idobj` (`Idobj`),
  KEY `Idmov` (`Idmov`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entidades`
--

DROP TABLE IF EXISTS `entidades`;
CREATE TABLE IF NOT EXISTS `entidades` (
  `Ident` int(11) NOT NULL AUTO_INCREMENT,
  `Empresa` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Nombres` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Apellidos` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Direccion` varchar(250) COLLATE latin1_spanish_ci NOT NULL,
  `Rfc` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `Movil` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `Correo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Pass` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `Foto` varchar(250) COLLATE latin1_spanish_ci NOT NULL,
  `Fecha` datetime NOT NULL,
  `Estado` tinyint(4) NOT NULL,
  `Tipo` int(11) NOT NULL,
  `Avatar` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Current_session` int(11) DEFAULT NULL,
  `Online` int(11) DEFAULT NULL,
  `Ident2` int(11)  NOT NULL,
  PRIMARY KEY (`Ident`),
  KEY `Ident2` (`Ident2`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `entidades`
--

INSERT INTO `entidades` (`Ident`, `Empresa`, `Nombres`, `Apellidos`, `Direccion`, `Rfc`, `Movil`, `Correo`, `Pass`, `Foto`, `Fecha`, `Estado`, `Tipo`, `Avatar`, `Current_session`, `Online`, `Ident2`) VALUES
(1, 'Empresas', '', '', '', '', '', 'empresas@pymes.com', 'us1317mx@', 'No', '2021-07-05 07:56:00', 1, 1, 'user1.jpg', 0, 0, 1),
(2, 'Usuarios', 'Jimmy', 'Villatoro', 'Ave cupape 911 entr4e andador los cocos y calle cipres col albania baja Tuxtla Gutiérrez, Chiapas México.', 'Viarj771014j83', '9611772089', 'jimmyvillatoro77@gmail.com', 'us1317mx@', 'No', '2021-07-04 19:46:00', 1, 2, 'user5.jpg', 5, 1, 1),
(3, 'Clientes', '', '', '', '', '', 'clientes@pymes.com', 'us1317mx@', 'No', '2021-07-04 19:46:00', 1, 3, 'user3.jpg', 0, 0, 1),
(4, 'Proveedores', '', '', '', '', '', 'proveedores@pymes.com', 'us1317mx@', 'No', '2021-07-04 19:46:00', 1, 4, 'user4.jpg', 0, 0, 1),
(5, 'Prospectos', '', '', '', '', '', 'prospectos@pymes.com', 'us1317mx@', 'No', '2021-07-04 19:46:00', 1, 5, 'user2.jpg', 0, 0, 1),
(6, 'cajero1', '', '', '', '', '', 'caja1@pymes.com', 'us1317mx@', '', '2021-07-07 09:55:25', 1, 2, 'user6.jpg', 0, 0, 1),
(7, 'cajero2', '', '', '', '', '', 'caja2@pymes.com', 'us1317mx@', '', '2021-07-07 09:55:25', 1, 2, 'user6.jpg', 0, 0, 1),
(8, 'cajero3', '', '', '', '', '', 'caja3@pymes.com', 'us1317mx@', '', '2021-07-07 09:55:25', 1, 2, 'user6.jpg', 0, 0, 1),
(9, 'cajero4', '', '', '', '', '', 'caja4@pymes.com', 'us1317mx@', '', '2021-07-07 09:55:25', 1, 2, 'user6.jpg', 0, 0, 1),
(10, 'cajero5', '', '', '', '', '', 'caja5@pymes.com', 'us1317mx@', '', '2021-07-07 09:55:25', 1, 2, 'user6.jpg', 0, 0, 1),
(11, 'almacen1', '', '', '', '', '', 'almacen1@pymes.com', 'us1317mx@', '', '2021-07-07 09:55:25', 1, 2, 'user3.jpg', 0, 0, 1),
(12, 'almacen2', '', '', '', '', '', 'almacen2@pymes.com', 'us1317mx@', '', '2021-07-07 09:55:25', 1, 2, 'user3.jpg', 0, 0, 1),
(13, 'almacen3', '', '', '', '', '', 'almacen3@pymes.com', 'us1317mx@', '', '2021-07-07 09:55:25', 1, 2, 'user3.jpg', 0, 0, 1),
(14, 'Cliente General', '', '', '', '', '', 'general1@pymes.com', 'us1317mx@', '', '2021-07-07 09:55:25', 1, 3, 'user4.jpg', 0, 0, 1),
(15, 'Proveedor General', '', '', '', '', '', 'general2@pymes.com', 'us1317mx@', '', '2021-07-07 09:55:25', 1, 4, 'user5.jpg', 0, 0, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movimientos`
--

DROP TABLE IF EXISTS `movimientos`;
CREATE TABLE IF NOT EXISTS `movimientos` (
  `Idmov` int(11) NOT NULL AUTO_INCREMENT,
  `Folio` int(11) DEFAULT NULL,
  `Fecha` datetime NOT NULL,
  `Tipo` int(11) NOT NULL,
  `Subtotal` float DEFAULT NULL,
  `Descuento` float DEFAULT NULL,
  `Iva` float DEFAULT NULL,
  `Total` float DEFAULT NULL,
  `Estado` int(11) NOT NULL,
  `Mensaje` varchar(250) COLLATE latin1_spanish_ci DEFAULT NULL,
  `Remitente` int(11) DEFAULT NULL,
  `Destinatario` int(11) DEFAULT NULL,
  `Ident` int(11) NOT NULL,
  PRIMARY KEY (`Idmov`),
  KEY `Ident` (`Ident`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `objetos`
--

DROP TABLE IF EXISTS `objetos`;
CREATE TABLE IF NOT EXISTS `objetos` (
  `Idobj` int(11) NOT NULL AUTO_INCREMENT,
  `Codigo` int(11) NOT NULL,
  `Nombre` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Categoria` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Descripcion` text COLLATE latin1_spanish_ci NOT NULL,
  `Cantidad` float NOT NULL,
  `Precio` float NOT NULL,
  `Descuento` float NOT NULL,
  `Maximo` int(11) NOT NULL,
  `Minimo` int(11) NOT NULL,
  `Caducidad` datetime NOT NULL,
  `Ubicacion` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Foto` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `Enlace` varchar(255) COLLATE latin1_spanish_ci NOT NULL,
  `Estado` int(11) NOT NULL,
  `Idobj2` int(11) NOT NULL,
  `Ident` int(11) NOT NULL,
  PRIMARY KEY (`Idobj`),
  KEY `Idobj2` (`Idobj2`,`Ident`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
