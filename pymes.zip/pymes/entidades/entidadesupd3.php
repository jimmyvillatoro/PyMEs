<?php 
include '../dat/cdb/db.php'; 

$idusu = $_REQUEST['idusu'];
$Ident= $_REQUEST['Ident'];
$Empresa= $_REQUEST['Empresa'];
$Nombres= $_REQUEST['Nombres'];
$Apellidos= $_REQUEST['Apellidos'];
$Direccion= $_REQUEST['Direccion'];
$Rfc= $_REQUEST['Rfc'];
$Movil= $_REQUEST['Movil'];
$Correo= $_REQUEST['Correo'];
$Pass= $_REQUEST['Pass'];
$Estado= $_REQUEST['Estado'];

$resultado=mysqli_query($db_connection, "SELECT * FROM entidades WHERE Ident = '".$Ident."'" ); 
if (mysqli_num_rows($resultado)>0) {
$update_value = "UPDATE entidades SET Empresa= '".$Empresa."', Nombres= '".$Nombres."', Apellidos= '".$Apellidos."', Direccion= '".$Direccion."', Rfc= '".$Rfc."', Movil= '".$Movil."', Correo= '".$Correo."', Pass= '".$Pass."', Estado= '".$Estado."'  WHERE   Ident = '".$Ident."'" ;  
$retry_value = mysqli_query($db_connection,$update_value);
 header("Location: entidadessel3.php?idusu=$idusu&Ident=$Ident"); 
mysqli_free_result($retry_value);
} else {  
 header("Location: entidadessel3.php?idusu=$idusu&Ident=$Ident"); }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>