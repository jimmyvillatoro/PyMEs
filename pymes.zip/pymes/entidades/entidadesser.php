<?php
session_start(); 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description: automata finitos" content="">
        <meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">
		<link href="../dat/css/style.css" rel="stylesheet" type="text/css" media="all" />
		<title>entidades</title> 

 
<?php
include '../dat/cdb/db.php';
$idusu = utf8_decode($_GET['idusu']); 
$Ident = utf8_decode($_GET['Ident']); 

if($_SESSION['Ident']!=$idusu)
{
 echo '<a href="sesion.php" title="" class="round">Inicie sesion</a>';
  header('Location: sesion.php?idses='.$_SESSION['Ident'].'');
  exit;
}

$resultado=mysqli_query($db_connection, "SELECT Nombres, Apellidos FROM entidades WHERE Ident = '".$idusu."' ");
while ($row =mysqli_fetch_array($resultado)) {
   	$nombres=$row['Nombres'];
   	$nombres.=" ".$row['Apellidos'];
   }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?> 

<script src="jquery-3.6.0.min.js"></script>
<script language=JavaScript>
$(document).ready(function(){
         $("#txtbusca").keyup(function(){
              var parametros="txtbusca="+$(this).val()
              $.ajax({
                    data:  parametros,
                  url:   "entidadesser2.php?idusu=<?php echo $idusu ?>",
                  type:  "post",
                    beforeSend: function () { },
                    success:  function (response) {                 
                        $(".salida").html(response);
                  },
                  error:function(){
                       alert("funcion error")
                    }
               });
         })
})
</script>
 


 
 <?php  
$Empresa = utf8_decode($_GET['Empresa']); 
?> 
</head>
<!-- Body -->
	<body>
		<div id="wrapper">
			<div id="logo">
				<h1>Control de<span> PyME</span></h1>
				<p>Area para tu PyME</p>
			</div>
			<div id="page" class="round">
				<div id="menu" class="round">
<ul>
<li><a href="../usuarios.php?Idmov=<?php echo $Idmov; ?>&Ident=<?php echo $Ident; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>" title="" class="round">Regresar</a></li>
</ul>
			</div>
<div id="content" class="round">
<p>Usuario:<a style="color:orange;"> <?php echo $nombres; ?> </a></p>
<div id="wrapper2" class="round">					
<div id="sidebar2" class="round">  
 
<div> <h2>Buscar entidad para editarla</h2> </div> 
 

<h2>busca por el campo <strong class="cur">Empresa</strong></h2>
<form action="entidadesser.php" method="POST">
  <input type="hidden" name="idusu" value="<?php echo utf8_decode($_GET['idusu']); ?>"> 
<div class="input-group mb-3">
          <input type="text" class="form-control" id="txtbusca" value="<?php echo  $Empresa; ?>" aria-label="Search" aria-describedby="basic-addon2">
       <div class="input-group-append">
          <span class="input-group-text" id="basic-addon2"></span>
        </div>
</div>
<div class="salida"></div>
</form>  
 
<a href="../usuarios.php?Ident=<?php echo $Ident; ?>&Ident2=<?php echo $Ident2; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
<h3>Información</h3>
<ul>
<li>Los datos están seguros en nuestra nube, pero puedes tener instalada nuestra plataforma en tu sitio web. Contactanos</li>
<li align="center">
<img src="../dat/ima/datos.jpg" alt="" width="200" height="150" class="round" />     
</li>
<li>Nosotros hicimos está plataforma pensando en un mejor rendimiento para su PyME.</li>
</ul>
<!-- End Sidebar -->
</div></div>
<!-- End Content -->
</div>
<div style="clear: both"></div>
<!-- End Wrapper 2 -->
</div>
<!-- End Page -->
</div>
<!-- End Wrapper -->
</div>
<div id="footer">
<p>copyright &copy; 2021 Jimmy Villatoro<a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p></div>
<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div>
</body>
</html>
  
