<?php 
include '../dat/cdb/db.php'; 

$idusu = $_REQUEST['idusu'];
$Empresa= $_REQUEST['Empresa'];
$Nombres= $_REQUEST['Nombres'];
$Apellidos= $_REQUEST['Apellidos'];
$Direccion= $_REQUEST['Direccion'];
$Rfc= $_REQUEST['Rfc'];
$Movil= $_REQUEST['Movil'];
$Correo= $_REQUEST['Correo'];
$Pass= $_REQUEST['Pass'];
$Foto= $_REQUEST['Foto'];
$Estado= $_REQUEST['Estado'];
$Tipo= $_REQUEST['Tipo'];
$Ident2= $_REQUEST['Ident2'];
 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; 
$resultado=mysqli_query($db_connection, "SELECT Ident FROM entidades WHERE Correo LIKE '".$Correo."'" ); 
if (mysqli_num_rows($resultado)>0) {
 header("Location: ../usuarios.php?idusu=$idusu&Ident=$Ident&Ident2=$Ident2"); 
} else {  
  
if($Ident2==1 && $Tipo==1){
$insert_value ="INSERT INTO entidades(Empresa, Nombres, Apellidos, Direccion, Rfc, Movil, Correo, Pass, Foto, Fecha, Estado, Tipo, Avatar, Ident2) VALUES ( '".$Empresa."',  '".$Nombres."',  '".$Apellidos."',  '".$Direccion."',  '".$Rfc."',  '".$Movil."',  '".$Correo."',  '".$Pass."',  '".$Foto."',  '".$dt."',  1,  '".$Tipo."',  'user1.jpg', '".$Ident2."')";
$retry_value = mysqli_query($db_connection,$insert_value);
$resultado=mysqli_query($db_connection, "SELECT Ident  FROM  entidades  WHERE Fecha= '".$dt."'" ); 
 while ($row =mysqli_fetch_array($resultado))   $Ident =$row['Ident']; 
 $update_value = "UPDATE entidades SET Ident2='".$Ident."'  WHERE Ident = '".$Ident."'" ;  
$retry_value = mysqli_query($db_connection,$update_value);
 
$insert_value ="INSERT INTO entidades(Empresa, Nombres, Apellidos, Direccion, Rfc, Movil, Correo, Pass, Foto, Fecha, Estado, Tipo, Avatar, Ident2) VALUES ('Usuarios',  'Nuevo','Nuevo', 'Conocida',  'no tiene',  11111,  'usuarionuevo@pymes.com',  'us1317mx@',  'no',  '".$dt."',  1,  2,  'user5.jpg',  '".$Ident."')";
$retry_value = mysqli_query($db_connection,$insert_value);

$insert_value ="INSERT INTO entidades(Empresa, Nombres, Apellidos, Direccion, Rfc, Movil, Correo, Pass, Foto, Fecha, Estado, Tipo, Avatar, Ident2) VALUES ('Cliente,  'Nuevo','Nuevo', 'Conocida',  'no tiene',  11111,  'clientenuevo@pymes.com',  'us1317mx@',  'no',  '".$dt."',  1,  3,  'user3.jpg',  '".$Ident."')";
$retry_value = mysqli_query($db_connection,$insert_value);

$insert_value ="INSERT INTO entidades(Empresa, Nombres, Apellidos, Direccion, Rfc, Movil, Correo, Pass, Foto, Fecha, Estado, Tipo, Avatar, Ident2) VALUES ('Proveedores',  'Nuevo','Nuevo', 'Conocida',  'no tiene',  11111,  'proveedornuevo@pymes.com',  'us1317mx@',  'no',  '".$dt."',  1, 4,  'user4.jpg',  '".$Ident."')";
$retry_value = mysqli_query($db_connection,$insert_value);

$insert_value ="INSERT INTO entidades(Empresa, Nombres, Apellidos, Direccion, Rfc, Movil, Correo, Pass, Foto, Fecha, Estado, Tipo, Avatar, Ident2) VALUES ('Prospectos',  'Nuevo','Nuevo', 'Conocida',  'no tiene',  11111,  'prospectonuevo@pymes.com',  'us1317mx@',  'no',  '".$dt."',  1,  5,  'user2.jpg',  '".$Ident."')";
$retry_value = mysqli_query($db_connection,$insert_value);

$insert_value ="INSERT INTO entidades(Empresa, Nombres, Apellidos, Direccion, Rfc, Movil, Correo, Pass, Foto, Fecha, Estado, Tipo, Avatar, Ident2) VALUES ('Cajero1',  'Nuevo','Nuevo', 'Conocida',  'no tiene',  11111,  'caja1nuevo@pymes.com',  'us1317mx@',  'no',  '".$dt."',  1,  '".$Tipo."',  'user6.jpg',  '".$Ident."')";
$retry_value = mysqli_query($db_connection,$insert_value);

$insert_value ="INSERT INTO entidades(Empresa, Nombres, Apellidos, Direccion, Rfc, Movil, Correo, Pass, Foto, Fecha, Estado, Tipo, Avatar, Ident2) VALUES ('Cajero2',  'Nuevo','Nuevo', 'Conocida',  'no tiene',  11111,  'caja2nuevo@pymes.com',  'us1317mx@',  'no',  '".$dt."',  1,  '".$Tipo."',  'user6.jpg',  '".$Ident."')";
$retry_value = mysqli_query($db_connection,$insert_value);
$insert_value ="INSERT INTO entidades(Empresa, Nombres, Apellidos, Direccion, Rfc, Movil, Correo, Pass, Foto, Fecha, Estado, Tipo, Avatar, Ident2) VALUES ('Cajero3',  'Nuevo','Nuevo', 'Conocida',  'no tiene',  11111,  'caja3nuevo@pymes.com',  'us1317mx@',  'no',  '".$dt."',  1,  '".$Tipo."',  'user6.jpg',  '".$Ident."')";
$retry_value = mysqli_query($db_connection,$insert_value);
$insert_value ="INSERT INTO entidades(Empresa, Nombres, Apellidos, Direccion, Rfc, Movil, Correo, Pass, Foto, Fecha, Estado, Tipo, Avatar, Ident2) VALUES ('Cajero4',  'Nuevo','Nuevo', 'Conocida',  'no tiene',  11111,  'caja4nuevo@pymes.com',  'us1317mx@',  'no',  '".$dt."',  1,  '".$Tipo."',  'user6.jpg',  '".$Ident."')";
$retry_value = mysqli_query($db_connection,$insert_value);
$insert_value ="INSERT INTO entidades(Empresa, Nombres, Apellidos, Direccion, Rfc, Movil, Correo, Pass, Foto, Fecha, Estado, Tipo, Avatar, Ident2) VALUES ('Cajero5',  'Nuevo','Nuevo', 'Conocida',  'no tiene',  11111,  'caja5nuevo@pymes.com',  'us1317mx@',  'no',  '".$dt."',  1,  '".$Tipo."',  'user6.jpg',  '".$Ident."')";
$retry_value = mysqli_query($db_connection,$insert_value);

$insert_value ="INSERT INTO entidades(Empresa, Nombres, Apellidos, Direccion, Rfc, Movil, Correo, Pass, Foto, Fecha, Estado, Tipo, Avatar, Ident2) VALUES ('Almacen1',  'Nuevo','Nuevo', 'Conocida',  'no tiene',  11111,  'almacen1nuevo@pymes.com',  'us1317mx@',  'no',  '".$dt."',  1,  '".$Tipo."',  'user3.jpg',  '".$Ident."')";
$retry_value = mysqli_query($db_connection,$insert_value);
$insert_value ="INSERT INTO entidades(Empresa, Nombres, Apellidos, Direccion, Rfc, Movil, Correo, Pass, Foto, Fecha, Estado, Tipo, Avatar, Ident2) VALUES ('Almacen2',  'Nuevo','Nuevo', 'Conocida',  'no tiene',  11111,  'almacen2nuevo@pymes.com',  'us1317mx@',  'no',  '".$dt."',  1,  '".$Tipo."',  'user3.jpg',  '".$Ident."')";
$retry_value = mysqli_query($db_connection,$insert_value);

$insert_value ="INSERT INTO entidades(Empresa, Nombres, Apellidos, Direccion, Rfc, Movil, Correo, Pass, Foto, Fecha, Estado, Tipo, Avatar, Ident2) VALUES ('Almacen3',  'Nuevo','Nuevo', 'Conocida',  'no tiene',  11111,  'almacen3nuevo@pymes.com',  'us1317mx@',  'no',  '".$dt."',  1,  '".$Tipo."',  'user3.jpg',  '".$Ident."')";
$retry_value = mysqli_query($db_connection,$insert_value);

$insert_value ="INSERT INTO entidades(Empresa, Nombres, Apellidos, Direccion, Rfc, Movil, Correo, Pass, Foto, Fecha, Estado, Tipo, Avatar, Ident2) VALUES ('Cliente General',  'Nuevo','Nuevo', 'Conocida',  'no tiene',  11111,  'clientegeneralnuevo@pymes.com',  'us1317mx@',  'no',  '".$dt."',  1,  3,  'user4.jpg',  '".$Ident."')";
$retry_value = mysqli_query($db_connection,$insert_value);

$insert_value ="INSERT INTO entidades(Empresa, Nombres, Apellidos, Direccion, Rfc, Movil, Correo, Pass, Foto, Fecha, Estado, Tipo, Avatar, Ident2) VALUES ('Proveedor General',  'Nuevo','Nuevo', 'Conocida',  'no tiene',  11111,  'proveedorgeneralnuevo@pymes.com',  'us1317mx@',  'no',  '".$dt."',  1,  4,  'user5.jpg',  '".$Ident."')";
$retry_value = mysqli_query($db_connection,$insert_value);



}else{
  
  $insert_value ="INSERT INTO entidades(Empresa, Nombres, Apellidos, Direccion, Rfc, Movil, Correo, Pass, Foto, Fecha, Estado, Tipo, Avatar, Ident2) VALUES ( '".$Empresa."',  '".$Nombres."',  '".$Apellidos."',  '".$Direccion."',  '".$Rfc."',  '".$Movil."',  '".$Correo."',  '".$Pass."',  '".$Foto."',  '".$dt."',  1,  '".$Tipo."',  'user1.jpg', '".$Ident2."')";

$retry_value = mysqli_query($db_connection,$insert_value);
  
}
  
}
$resultado=mysqli_query($db_connection, "SELECT Ident  FROM  entidades  WHERE Empresa = '".$Empresa."'" ); 
 while ($row =mysqli_fetch_array($resultado))   $Ident =$row['Ident']; 
 header("Location: ../usuarios.php?idusu=$idusu&Ident=$Ident&Ident2=$Ident2"); 
mysqli_free_result($retry_value);
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>