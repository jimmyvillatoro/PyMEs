<?php 
include '../dat/cdb/db.php'; 
$idusu = $_REQUEST['idusu'];


$Empresa= $_REQUEST['Empresa'];
$Nombres= $_REQUEST['Nombres'];
$Apellidos= $_REQUEST['Apellidos'];
$Direccion= $_REQUEST['Direccion'];
$Rfc= $_REQUEST['Rfc'];
$Movil= $_REQUEST['Movil'];
$Correo= $_REQUEST['Correo'];
$Pass= $_REQUEST['Pass'];
$Foto= $_REQUEST['Foto'];
$Fecha= $_REQUEST['Fecha'];
$Estado= $_REQUEST['Estado'];
$Tipo= $_REQUEST['Tipo'];
$Ident2= $_REQUEST['Ident2'];
$Idx= $_REQUEST['Idx'];
 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time;  
$resultado=mysqli_query($db_connection, "SELECT * FROM entidades WHERE Ident LIKE '".$Idx."'" );  
if (mysqli_num_rows($resultado)>0) {
$delete_value ="DELETE FROM entidades WHERE Ident LIKE '".$Idx."'";  
$retry_value = mysqli_query($db_connection,$delete_value);
 header("Location: ../entidades/entidadessel2.php?idusu=$idusu"); 
mysqli_free_result($retry_value);
} else {  
 header("Location: ../entidades/entidadessel2.php?idusu=$idusu"); }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>