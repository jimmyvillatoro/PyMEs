<?php 
include '../dat/cdb/db.php'; 

$idusu = $_REQUEST['idusu'];
$idses = $_REQUEST['idses'];
 
$Ident= $_REQUEST['Ident'];
$Empresa= $_REQUEST['Empresa'];
$Nombres= $_REQUEST['Nombres'];
$Apellidos= $_REQUEST['Apellidos'];
$Direccion= $_REQUEST['Direccion'];
$Rfc= $_REQUEST['Rfc'];
$Movil= $_REQUEST['Movil'];
$Correo= $_REQUEST['Correo'];
$Pass= $_REQUEST['Pass'];
$Foto= $_REQUEST['Foto'];
$Fecha= $_REQUEST['Fecha'];
$Estado= $_REQUEST['Estado'];

date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time;  
$resultado=mysqli_query($db_connection, "SELECT * FROM entidades WHERE Ident = '".$Ident."'" ); 
if (mysqli_num_rows($resultado)>0) {
$update_value = "UPDATE entidades SET Empresa= '".$Empresa."', Nombres= '".$Nombres."', Apellidos= '".$Apellidos."', Direccion= '".$Direccion."', Rfc= '".$Rfc."', Movil= '".$Movil."', Correo= '".$Correo."', Pass= '".$Pass."', Foto= '".$Foto."', Estado= '".$Estado."'  WHERE   Ident = '".$Ident."'" ;  
$retry_value = mysqli_query($db_connection,$update_value);
 header("Location: ../usuarios.php?idusu=$idusu&idses=$idses&Ident=$Ident&Ident2=$Ident2"); 
mysqli_free_result($retry_value);
} else {  
 header("Location: ../usuarios.php?idusu=$idusu&idses=$idses&Ident=$Ident&Ident2=$Ident2"); }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>