<?php 
include '../dat/cdb/db.php'; 

$idusu = $_REQUEST['idusu'];
$idses = $_REQUEST['idses'];
$Iddet = $_REQUEST['Iddet'];
$Idmov = $_REQUEST['Idmov']; 
$Idmov = $_REQUEST['Idmov'];
 
$html=""; 
$busca= $_REQUEST["txtbusca"]; 
$html.="<h2><strong class='cur'>Resultados</h2>"; 
 
$resultado=mysqli_query($db_connection, "SELECT * FROM detalle WHERE Cantidad LIKE '%".$busca."%'" );  
if (mysqli_num_rows($resultado)>0) {
while ($row =mysqli_fetch_array($resultado)) { 
$Iddet=$row['Iddet'];
$html.= '<p><a href=detallesel2.php?Iddet='.$Iddet.'>'.$Iddet.'</a></p></b>';$html.= '<p>'.$Iddet.'</p></b>'; 
$Cantidad=$row['Cantidad'];
$html.= '<p>'.$Cantidad.'</p></b>'; 
$Precio=$row['Precio'];
$html.= '<p>'.$Precio.'</p></b>'; 
$Descuento=$row['Descuento'];
$html.= '<p>'.$Descuento.'</p></b>'; 
$Importe=$row['Importe'];
$html.= '<p>'.$Importe.'</p></b>'; 
$Fecha=$row['Fecha'];
$html.= '<p>'.$Fecha.'</p></b>'; 
$Idobj=$row['Idobj'];
$html.= '<p>'.$Idobj.'</p></b>'; 
$Idmov=$row['Idmov'];
$html.= '<p>'.$Idmov.'</p></b>'; 
} 
$html.="</b>"; 
echo $html; 
} 
else
echo 
"Is not found"; 

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>