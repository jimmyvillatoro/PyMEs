<?php 
include '../dat/cdb/db.php'; 

$idusu = $_REQUEST['idusu'];
$idses = $_REQUEST['idses'];
$Iddet = $_REQUEST['Iddet'];
$Idmov = $_REQUEST['Idmov']; 
$Idmov = $_REQUEST['Idmov'];
 
$Iddet= $_REQUEST['Iddet'];
$Cantidad= $_REQUEST['Cantidad'];
$Precio= $_REQUEST['Precio'];
$Descuento= $_REQUEST['Descuento'];
$Importe= $_REQUEST['Importe'];
$Fecha= $_REQUEST['Fecha'];
$Idobj= $_REQUEST['Idobj'];
$Idmov= $_REQUEST['Idmov'];
 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time;  
$resultado=mysqli_query($db_connection, "SELECT * FROM detalle WHERE Iddet = '".$Iddet."'" ); 
if (mysqli_num_rows($resultado)>0) {
$update_value = "UPDATE detalle SET Cantidad= '".$Cantidad."', Precio= '".$Precio."', Descuento= '".$Descuento."', Importe= '".$Importe."', Fecha= '".$Fecha."', Idobj= '".$Idobj."', Idmov= '".$Idmov."'   WHERE   Iddet = '".$Iddet."'" ;  
$retry_value = mysqli_query($db_connection,$update_value);
 header("Location: ../usuarios.php?idusu=$idusu&idses=$idses&Iddet=$Iddet&Idmov=$Idmov"); 
mysqli_free_result($retry_value);
} else {  
 header("Location: ../usuarios.php?idusu=$idusu&idses=$idses&Iddet=$Iddet&Idmov=$Idmov"); }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>