<?php 
include '../dat/cdb/db.php'; 

$idusu = $_REQUEST['idusu'];
$idses = $_REQUEST['idses'];
$Iddet = $_REQUEST['Iddet'];
$Idmov = $_REQUEST['Idmov']; 
$Idmov = $_REQUEST['Idmov'];
 
$Iddet= $_REQUEST['Iddet'];
$Cantidad= $_REQUEST['Cantidad'];
$Precio= $_REQUEST['Precio'];
$Descuento= $_REQUEST['Descuento'];
$Importe= $_REQUEST['Importe'];
$Fecha= $_REQUEST['Fecha'];
$Idobj= $_REQUEST['Idobj'];
$Idmov= $_REQUEST['Idmov'];
 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time; 
$resultado=mysqli_query($db_connection, "SELECT * FROM detalle WHERE Cantidad LIKE '".$Cantidad."'" ); 
if (mysqli_num_rows($resultado)>0) {
 header("Location: ../usuarios.php?idusu=$idusu&idses=$idses&Iddet=$Iddet&Idmov=$Idmov"); 
} else {  
$insert_value ="INSERT INTO detalle(Cantidad, Precio, Descuento, Importe, Fecha, Idobj, Idmov) VALUES ( '".$Cantidad."',  '".$Precio."',  '".$Descuento."',  '".$Importe."',  '".$Fecha."',  '".$Idobj."',  '".$Idmov."')";

$retry_value = mysqli_query($db_connection,$insert_value);}
$resultado=mysqli_query($db_connection, "SELECT Iddet  FROM  detalle  WHERE Cantidad = '".$Cantidad."'" ); 
 while ($row =mysqli_fetch_array($resultado))   $Iddet =$row['Iddet']; 
 header("Location: ../usuarios.php?idusu=$idusu&idses=$idses&Iddet=$Iddet&Idmov=$Idmov"); 
mysqli_free_result($retry_value);
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>