<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description: automata finito" content="">
        <meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">
		<title>detalle</title> 
  

<?php
include 'db.php'; 
$Cantidad= utf8_decode($_GET['Cantidad']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM detalle WHERE Cantidad LIKE '".$Cantidad."'" );
while ($row =mysqli_fetch_array($resultado)) 
{  
$Iddet=$row['Iddet'];
$Cantidad=$row['Cantidad'];
$Precio=$row['Precio'];
$Descuento=$row['Descuento'];
$Importe=$row['Importe'];
$Fecha=$row['Fecha'];
$Idobj=$row['Idobj'];
$Idmov=$row['Idmov'];
 } 
 mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
 
</head> 
<!-- body --> 
<body> 
<div> 
<h2>'.detalle.'</h2> 
</div> 
<h3>Seleccionar datos</h3><table  class='default' >
  <colgroup>
  <colgroup span='3' style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'>
  <colgroup span=8 style='background: rgba(255, 128, 0, 0.3); border: 1px solid rgba(200, 100, 0, 0.3);'>
  <tr><th>Iddet</th> 
<th>Cantidad</th> 
<th>Precio</th> 
<th>Descuento</th> 
<th>Importe</th> 
<th>Fecha</th> 
<th>Idobj</th> 
<th>Idmov</th> 
</tr><tbody style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'> <tr><th><?php echo $Iddet; ?></th> 
<th><?php echo $Cantidad; ?></th> 
<th><?php echo $Precio; ?></th> 
<th><?php echo $Descuento; ?></th> 
<th><?php echo $Importe; ?></th> 
<th><?php echo $Fecha; ?></th> 
<th><?php echo $Idobj; ?></th> 
<th><?php echo $Idmov; ?></th> 
</tr></table></br></br> 
 
<a href="../usuarios.php?Iddet=<?php echo $Iddet; ?>&Idmov=<?php echo $Idmov; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
</body> </html>