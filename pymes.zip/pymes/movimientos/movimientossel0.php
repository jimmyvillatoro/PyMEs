<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description: automata finito" content="">
        <meta name="author: Jimmy Villatoro" content="jimmyvillatoro77@gmail.com">
		<title>movimientos</title> 
  

<?php
include 'db.php'; 
$Folio= utf8_decode($_GET['Folio']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM movimientos WHERE Folio LIKE '".$Folio."'" );
while ($row =mysqli_fetch_array($resultado)) 
{  
$Idmov=$row['Idmov'];
$Folio=$row['Folio'];
$Fecha=$row['Fecha'];
$Tipo=$row['Tipo'];
$Subtotal=$row['Subtotal'];
$Descuento=$row['Descuento'];
$Total=$row['Total'];
$Estado=$row['Estado'];
$Mensaje=$row['Mensaje'];
$Destinatario=$row['Destinatario'];
$Ident=$row['Ident'];
 } 
 mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
 
</head> 
<!-- body --> 
<body> 
<div> 
<h2>'.movimientos.'</h2> 
</div> 
<h3>Seleccionar datos</h3><table  class='default' >
  <colgroup>
  <colgroup span='3' style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'>
  <colgroup span=11 style='background: rgba(255, 128, 0, 0.3); border: 1px solid rgba(200, 100, 0, 0.3);'>
  <tr><th>Idmov</th> 
<th>Folio</th> 
<th>Fecha</th> 
<th>Tipo</th> 
<th>Subtotal</th> 
<th>Descuento</th> 
<th>Total</th> 
<th>Estado</th> 
<th>Mensaje</th> 
<th>Destinatario</th> 
<th>Ident</th> 
</tr><tbody style='background: rgba(128, 255, 0, 0.3); border: 1px solid rgba(100, 200, 0, 0.3);'> <tr><th><?php echo $Idmov; ?></th> 
<th><?php echo $Folio; ?></th> 
<th><?php echo $Fecha; ?></th> 
<th><?php echo $Tipo; ?></th> 
<th><?php echo $Subtotal; ?></th> 
<th><?php echo $Descuento; ?></th> 
<th><?php echo $Total; ?></th> 
<th><?php echo $Estado; ?></th> 
<th><?php echo $Mensaje; ?></th> 
<th><?php echo $Destinatario; ?></th> 
<th><?php echo $Ident; ?></th> 
</tr></table></br></br> 
 
<a href="../usuarios.php?Idmov=<?php echo $Idmov; ?>&Ident=<?php echo $Ident; ?>&idusu=<?php echo $idusu; ?>&idses=<?php echo $idses; ?>">Regresar</a>
</body> </html>